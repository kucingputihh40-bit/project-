NEXATECH - PENGEMBANGAN FITUR SCHEDULE & PROFILE

Cara menjalankan:
1. Ekstrak file ZIP.
2. Buka folder NexaTech_Schedule_Profile.
3. Klik dua kali index.html atau buka menggunakan Live Server di Visual Studio Code.
4. Pastikan koneksi internet aktif karena Bootstrap, Bootstrap Icons, Google Fonts, dan foto menggunakan CDN/URL eksternal.

Fitur tambahan:
- Menu Schedule dengan filter Semua Hari/Senin-Jumat.
- Jadwal menampilkan hari, jam, mata kuliah, dan ruang.
- Layout jadwal responsif: grid pada desktop/tablet dan daftar vertikal pada ponsel.
- Menu Profile dengan foto dan tabel data mahasiswa.
- Layout profile responsif: foto di sisi kiri pada desktop dan terpusat di atas data pada ponsel.

PENTING:
Data jadwal merupakan contoh dan harus disesuaikan dengan jadwal kuliah sebenarnya.
Program studi, email, nomor telepon, dan alamat pada Profile perlu dilengkapi sebelum dikumpulkan.
Foto profil contoh dapat diganti dengan foto pribadi.
